-- 创建一个存储过程，用于更新一个毕业生的就业信息
CREATE PROCEDURE update_employment @student_id VARCHAR(10),
                                   @employer_id INT,
                                   @position VARCHAR(50),
                                   @contract_date DATE,
                                   @salary INT
AS
BEGIN
    -- 检查输入参数是否合法
    IF @student_id IS NULL OR @employer_id IS NULL
        RAISERROR (N'参数不合法', 16, 1)

    -- 检查学号是否存在
    IF NOT EXISTS (SELECT * FROM graduates WHERE student_id = @student_id)
        RAISERROR (N'学号不存在', 16, 1)

    -- 检查就业单位ID是否存在
    IF NOT EXISTS (SELECT * FROM employer WHERE employer_id = @employer_id)
        RAISERROR (N'就业单位ID不存在', 16, 1)

    -- 查询毕业生的就业ID，如果没有则创建一个新的就业记录并返回就业ID，如果有则更新就业记录并返回就业ID
    DECLARE @employment_id INT

    SELECT @employment_id = employment_id FROM graduates WHERE student_id = @student_id

    IF @employment_id IS NULL
        BEGIN
            INSERT INTO employment (employer_id, position, contract_date, salary) VALUES (@employer_id, @position, @contract_date, @salary)

            SET @employment_id = SCOPE_IDENTITY()

            UPDATE graduates SET employment_id = @employment_id WHERE student_id = @student_id
        END
    ELSE
        BEGIN
            UPDATE employment SET employer_id = @employer_id, position = @position, contract_date = @contract_date, salary = @salary WHERE employment_id = @employment_id

            SELECT employment_id INTO employment_id FROM employment WHERE employer_id = @employer_id AND position = @position AND contract_date = @contract_date AND salary = @salary
        END

END
GO

