-- 创建一个触发器，当就业表中删除数据时，将对应的毕业生表中的就业ID设置为NULL
CREATE TRIGGER delete_employment_id
    ON employment
    AFTER DELETE
    AS
BEGIN
    DECLARE @employment_id INT;
    SELECT @employment_id = employment_id FROM deleted;
    UPDATE graduates SET employment_id = NULL WHERE employment_id = @employment_id;
END;
GO

