-- 创建一个存储过程，用于查询一个毕业生的所有成绩信息，包括科目名称和成绩分数，并按照成绩分数降序排序
CREATE PROCEDURE query_grades @student_id VARCHAR(10)
AS
BEGIN
    -- 检查输入参数是否合法
    IF @student_id IS NULL
        RAISERROR (N'参数无效', 16, 1)

    -- 检查学号是否存在
    IF NOT EXISTS (SELECT * FROM graduates WHERE student_id = @student_id)
        RAISERROR (N'学号不存在', 16, 1)

    -- 查询成绩信息并排序
    SELECT s.subject_name, g.grade_score
    FROM grades g
             JOIN subjects s ON g.subject_id = s.subject_id
    WHERE g.student_id = @student_id
    ORDER BY g.grade_score DESC
END
GO

