-- 创建一个触发器，当毕业生表中插入或更新数据时，检查毕业时间是否晚于入学时间，如果不是，则回滚事务并抛出错误
CREATE TRIGGER check_graduation_date
    ON graduates
    AFTER INSERT, UPDATE
    AS
BEGIN
    IF EXISTS (SELECT * FROM inserted WHERE graduation_date <= enrollment_date)
        BEGIN
            ROLLBACK TRANSACTION;
            RAISERROR (N'毕业时间必须晚于入学时间', 16, 1);
        END
END;
GO

