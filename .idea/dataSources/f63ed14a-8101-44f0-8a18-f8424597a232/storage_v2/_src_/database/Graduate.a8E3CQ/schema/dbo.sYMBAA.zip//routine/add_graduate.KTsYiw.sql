-- 创建一个存储过程，用于添加一个新的毕业生信息
CREATE PROCEDURE add_graduate @student_id VARCHAR(10),
                              @name VARCHAR(20),
                              @gender CHAR(2),
                              @birth_date DATE,
                              @id_card CHAR(18),
                              @contact VARCHAR(50),
                              @major_id INT,
                              @enrollment_date DATE,
                              @graduation_date DATE,
                              @degree_date DATE,
                              @employment_id INT
AS
BEGIN
    -- 检查输入参数是否合法
    IF @student_id IS NULL OR @name IS NULL OR @gender IS NULL OR @birth_date IS NULL OR @id_card IS NULL OR @major_id IS NULL OR @enrollment_date IS NULL OR @graduation_date IS NULL
        RAISERROR (N'参数不合法', 16, 1)

    -- 检查学号是否已存在
    IF EXISTS (SELECT * FROM graduates WHERE student_id = @student_id)
        RAISERROR (N'学号已存在', 16, 1)

    -- 检查身份证号是否已存在
    IF EXISTS (SELECT * FROM graduates WHERE id_card = @id_card)
        RAISERROR (N'身份证号已存在', 16, 1)

    -- 检查专业ID是否存在
    IF NOT EXISTS (SELECT * FROM majors WHERE major_id = @major_id)
        RAISERROR (N'专业ID不存在', 16, 1)

    -- 检查就业ID是否存在
    IF @employment_id IS NOT NULL AND NOT EXISTS (SELECT * FROM employment WHERE employment_id = @employment_id)
        RAISERROR (N'就业ID不存在', 16, 1)

    -- 插入新的毕业生信息
    INSERT INTO graduates VALUES (@student_id, @name, @gender, @birth_date, @id_card, @contact, @major_id, @enrollment_date, @graduation_date, @degree_date, @employment_id)
END
GO

