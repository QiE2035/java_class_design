-- 创建一个触发器，当毕业生表中删除数据时，将对应的成绩表中的数据也删除
CREATE TRIGGER delete_grades
    ON graduates
    AFTER DELETE
    AS
BEGIN
    DECLARE @student_id VARCHAR(10);
    SELECT @student_id = student_id FROM deleted;
    DELETE FROM grades WHERE student_id = @student_id;
END;
GO

