-- 创建一个触发器，当专业表中插入或更新数据时，检查专业名称是否重复，如果是，则回滚事务并抛出错误
CREATE TRIGGER check_major_name
    ON majors
    AFTER INSERT, UPDATE
    AS
BEGIN
    IF EXISTS (SELECT *
               FROM inserted i
                        JOIN majors m ON i.major_id <> m.major_id AND i.major_name = m.major_name)
        BEGIN
            ROLLBACK TRANSACTION;
            RAISERROR (N'专业名称不能重复', 16, 1);
        END
END;
GO

