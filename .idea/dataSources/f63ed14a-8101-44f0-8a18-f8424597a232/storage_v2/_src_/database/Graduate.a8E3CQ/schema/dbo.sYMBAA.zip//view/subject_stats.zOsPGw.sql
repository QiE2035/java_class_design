-- 创建一个视图，显示每个科目的平均成绩和最高成绩
CREATE VIEW subject_stats AS
SELECT s.subject_name AS 科目, AVG(g.grade_score) AS 平均分, MAX(g.grade_score) AS 最高分
FROM subjects s
         JOIN grades g ON s.subject_id = g.subject_id
GROUP BY s.subject_name
GO

