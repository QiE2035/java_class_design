-- 创建一个存储过程，用于查询一个毕业生的所有信息，包括姓名，性别，出生日期，身份证号，联系方式，专业名称，学位类型，入学时间，毕业时间，学位授予时间，就业单位名称，就业职位，合同期限和薪水
CREATE PROCEDURE query_graduate_info @student_id VARCHAR(10)
AS
BEGIN
    -- 检查输入参数是否合法
    IF @student_id IS NULL
        RAISERROR (N'参数不合法', 16, 1)

    -- 检查学号是否存在
    IF NOT EXISTS (SELECT * FROM graduates WHERE student_id = @student_id)
        RAISERROR (N'学号不存在', 16, 1)

    -- 查询毕业生信息
    SELECT g.name,
           g.gender,
           g.birth_date,
           g.id_card,
           g.contact,
           m.major_name,
           m.degree_type,
           g.enrollment_date,
           g.graduation_date,
           g.degree_date,
           er.employer_name,
           e.position,
           e.contract_date,
           e.salary
    FROM graduates g
             JOIN majors m ON g.major_id = m.major_id
             LEFT JOIN employment e ON g.employment_id = e.employment_id
             LEFT JOIN employer er ON e.employer_id = er.employer_id -- 添加了这一行，连接 employer 表并指定别名 er
    WHERE g.student_id = @student_id
END
GO

