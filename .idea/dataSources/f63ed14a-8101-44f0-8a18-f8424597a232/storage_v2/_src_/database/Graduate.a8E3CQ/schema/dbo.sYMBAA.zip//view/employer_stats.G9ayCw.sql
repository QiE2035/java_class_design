-- 创建一个视图，显示每个就业单位的招聘人数和平均薪水
CREATE VIEW employer_stats AS
SELECT e.employer_name AS 工作单位, COUNT(em.employment_id) AS 招聘人数, AVG(em.salary) AS 平均薪水
FROM employer e
         JOIN employment em ON e.employer_id = em.employer_id
GROUP BY e.employer_name
GO

