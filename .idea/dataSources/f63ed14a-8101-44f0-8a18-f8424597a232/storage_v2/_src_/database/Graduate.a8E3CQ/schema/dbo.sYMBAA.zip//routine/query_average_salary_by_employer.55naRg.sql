-- 创建一个存储过程，用于查询一个就业单位的平均薪水，包括就业单位名称和平均薪水，并按照平均薪水降序排序
CREATE PROCEDURE query_average_salary_by_employer
AS
BEGIN
    -- 查询平均薪水并排序
    SELECT employer.employer_name, AVG(employment.salary) AS average_salary
    FROM employer
             JOIN employment ON employment.employer_id = employer.employer_id
    GROUP BY employer.employer_name
    ORDER BY average_salary DESC
END
GO

