-- 创建一个视图，显示每个毕业生的姓名、专业、科目和成绩
CREATE VIEW graduate_grades AS
SELECT g.name AS 姓名, m.major_name AS 专业, s.subject_name AS 科目, gr.grade_score AS 成绩
FROM graduates g
         JOIN majors m ON g.major_id = m.major_id
         JOIN grades gr ON g.student_id = gr.student_id
         JOIN subjects s ON gr.subject_id = s.subject_id
GO

