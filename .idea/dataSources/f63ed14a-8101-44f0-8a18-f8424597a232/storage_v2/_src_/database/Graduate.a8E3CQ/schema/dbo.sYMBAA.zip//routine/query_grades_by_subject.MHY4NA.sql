-- 创建一个存储过程，用于查询一个科目的所有成绩信息，包括学号，姓名，成绩分数，并按照成绩分数降序排序
CREATE PROCEDURE query_grades_by_subject @subject_id INT
AS
BEGIN
    -- 检查输入参数是否合法
    IF @subject_id IS NULL
        RAISERROR (N'参数不合法', 16, 1)

    -- 检查科目ID是否存在
    IF NOT EXISTS (SELECT * FROM subjects WHERE subject_id = @subject_id)
        RAISERROR (N'科目ID不存在', 16, 1)

    -- 查询成绩信息并排序
    SELECT grades.student_id, graduates.name, grades.grade_score
    FROM grades
             JOIN graduates ON grades.student_id = graduates.student_id
    WHERE grades.subject_id = @subject_id
    ORDER BY grades.grade_score DESC
END
GO

