-- 创建一个存储过程，用于查询一个就业单位的所有毕业生信息，包括学号，姓名，专业名称，就业职位，并按照学号升序排序
CREATE PROCEDURE query_graduates_by_employer @employer_id INT
AS
BEGIN
    -- 检查输入参数是否合法
    IF @employer_id IS NULL
        RAISERROR (N'参数不合法', 16, 1)

    -- 检查就业单位ID是否存在
    IF NOT EXISTS (SELECT * FROM employer WHERE employer_id = @employer_id)
        RAISERROR (N'就业单位ID不存在', 16, 1)

    -- 查询毕业生信息并排序
    SELECT g.student_id, g.name, m.major_name, e.position
    FROM graduates g
             JOIN majors m ON g.major_id = m.major_id
             JOIN employment e ON g.employment_id = e.employment_id
    WHERE e.employer_id = @employer_id
    ORDER BY g.student_id
END
GO

