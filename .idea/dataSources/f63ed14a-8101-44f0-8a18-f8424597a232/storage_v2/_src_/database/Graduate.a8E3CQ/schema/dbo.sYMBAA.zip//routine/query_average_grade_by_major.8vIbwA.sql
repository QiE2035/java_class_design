-- 创建一个存储过程，用于查询一个专业的平均成绩分数，包括专业名称和平均分数，并按照平均分数降序排序
CREATE PROCEDURE query_average_grade_by_major
AS
BEGIN
    -- 查询平均成绩分数并排序
    SELECT m.major_name, AVG(grades.grade_score) AS average_score
    FROM majors m
             JOIN graduates ON m.major_id = graduates.major_id
             JOIN grades ON graduates.student_id = grades.student_id
    GROUP BY m.major_name
    ORDER BY average_score DESC
END
GO

