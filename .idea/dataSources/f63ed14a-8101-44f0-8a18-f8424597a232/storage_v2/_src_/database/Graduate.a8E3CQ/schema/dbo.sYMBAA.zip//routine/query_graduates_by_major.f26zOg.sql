-- 创建一个存储过程，用于查询一个专业的所有毕业生信息，包括姓名，性别，毕业时间，就业单位名称和就业职位，并按照毕业时间升序排序
CREATE PROCEDURE query_graduates_by_major @major_id INT
AS
BEGIN
    -- 检查输入参数是否合法
    IF @major_id IS NULL
        RAISERROR (N'参数不合法', 16, 1)

    -- 检查专业ID是否存在
    IF NOT EXISTS (SELECT * FROM majors WHERE major_id = @major_id)
        RAISERROR (N'专业ID不存在', 16, 1)

    -- 查询毕业生信息并排序
    SELECT g.name, g.gender, g.graduation_date, er.employer_name, e.position -- 修改了这一行，使用了 employer 表的别名 er
    FROM graduates g
             LEFT JOIN employment e ON g.employment_id = e.employment_id
             LEFT JOIN employer er ON e.employer_id = er.employer_id -- 添加了这一行，连接 employer 表并指定别名 er
    WHERE g.major_id = @major_id
    ORDER BY g.graduation_date
END
GO

