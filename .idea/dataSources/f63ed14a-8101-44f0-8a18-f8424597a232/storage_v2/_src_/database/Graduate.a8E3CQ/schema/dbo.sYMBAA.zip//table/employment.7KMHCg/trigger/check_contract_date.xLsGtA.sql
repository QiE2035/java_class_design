-- 创建一个触发器，当就业表中插入或更新数据时，检查合同期限是否晚于毕业时间，如果不是，则回滚事务并抛出错误
CREATE TRIGGER check_contract_date
    ON employment
    AFTER INSERT, UPDATE
    AS
BEGIN
    IF EXISTS (SELECT *
               FROM inserted i
                        JOIN graduates g ON i.employment_id = g.employment_id
               WHERE i.contract_date <= g.graduation_date)
        BEGIN
            ROLLBACK TRANSACTION;
            RAISERROR (N'合同期限必须晚于毕业时间', 16, 1);
        END
END;
GO

