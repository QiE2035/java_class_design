-- 创建一个视图，显示每个专业的毕业生人数和平均薪水
CREATE VIEW major_stats AS
SELECT m.major_name AS 专业, COUNT(g.student_id) AS 毕业人数, AVG(e.salary) AS 平均薪水
FROM majors m
         JOIN graduates g ON m.major_id = g.major_id
         JOIN employment e ON g.employment_id = e.employment_id
GROUP BY m.major_name
GO

