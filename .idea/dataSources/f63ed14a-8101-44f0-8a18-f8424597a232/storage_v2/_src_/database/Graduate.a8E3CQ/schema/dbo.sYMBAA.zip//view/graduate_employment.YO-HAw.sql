-- 创建一个视图，显示每个毕业生的姓名、专业、就业单位和薪水
CREATE VIEW graduate_employment AS
SELECT g.name 姓名, m.major_name 专业, e.employer_name 就业单位, em.salary 薪水
FROM graduates g
         JOIN majors m ON g.major_id = m.major_id
         JOIN employment em ON g.employment_id = em.employment_id
         JOIN employer e ON em.employer_id = e.employer_id
GO

