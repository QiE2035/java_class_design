-- 创建一个触发器，当科目表中插入或更新数据时，检查科目名称是否重复，如果是，则回滚事务并抛出错误
CREATE TRIGGER check_subject_name
    ON subjects
    AFTER INSERT, UPDATE
    AS
BEGIN
    IF EXISTS (SELECT *
               FROM inserted i
                        JOIN subjects s ON i.subject_id != s.subject_id AND i.subject_name = s.subject_name)
        BEGIN
            ROLLBACK TRANSACTION;
            RAISERROR (N'科目名称不能重复', 16, 1);
        END
END;
GO

